import React, { useEffect, useState, useRef } from "react";
import Sidebar from "../components/sidebar";
import { collection, getDocs, onSnapshot } from "firebase/firestore";
import { db } from "../firebase/config";
import { FiEye } from "react-icons/fi";
import { useNavigate } from "react-router-dom";

export default function Users() {
  const [users, setUsers] = useState([]);
  const [userType, setUserType] = useState("drivers");
  const [search, setSearch] = useState("");
  const [selectedUser, setSelectedUser] = useState(null);
  const [addressData, setAddressData] = useState(null);
  const [page, setPage] = useState(1);
  const perPage = 25;
  const navigate = useNavigate();
  const tableRef = useRef(null);

  // === Charger les données ===
  useEffect(() => {
    const unsub = onSnapshot(collection(db, userType), (snapshot) => {
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
        type: userType === "drivers" ? "Driver" : "Sender",
      }));
      setUsers(data);
      setSelectedUser(null);
      setAddressData(null);
    });
    return () => unsub();
  }, [userType]);

  // === Charger la sous-collection "address" pour les drivers ===
  useEffect(() => {
    const loadAddress = async () => {
      if (selectedUser && userType === "drivers") {
        try {
          const addrSnap = await getDocs(
            collection(db, `drivers/${selectedUser.id}/address`)
          );
          if (!addrSnap.empty) {
            setAddressData(addrSnap.docs[0].data());
          } else {
            setAddressData(null);
          }
        } catch (e) {
          console.error("Erreur chargement adresse:", e);
        }
      } else {
        setAddressData(null);
      }
    };
    loadAddress();
  }, [selectedUser, userType]);

  // === Désélectionner quand on clique à l’extérieur ===
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (tableRef.current && !tableRef.current.contains(e.target)) {
        setSelectedUser(null);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // === Filtrage & pagination ===
  const filteredUsers = users.filter(
    (u) =>
      (u.fullName || u.name || "")
        .toLowerCase()
        .includes(search.toLowerCase()) ||
      (u.email || "").toLowerCase().includes(search.toLowerCase())
  );
  const totalPages = Math.ceil(filteredUsers.length / perPage);
  const startIndex = (page - 1) * perPage;
  const currentUsers = filteredUsers.slice(startIndex, startIndex + perPage);
  const nextPage = () => page < totalPages && setPage(page + 1);
  const prevPage = () => page > 1 && setPage(page - 1);

  // === Couleur du statut ===
  const getStatusColor = (user) => {
    if (userType === "drivers") {
      switch (user.status) {
        case "approved":
          return "#16A34A";
        case "pending":
          return "#F59E0B";
        case "under_review":
          return "#2563EB";
        case "on_hold":
          return "#D97706";
        case "banned":
          return "#DC2626";
        default:
          return "#6B7280";
      }
    } else {
      return user.isActive ? "#16A34A" : "#DC2626";
    }
  };

  // === Statistiques ===
  const getStats = () => {
    if (userType === "drivers") {
      const total = users.length;
      const approved = users.filter((u) => u.status === "approved").length;
      const pending = users.filter((u) => u.status === "pending").length;
      const review = users.filter((u) => u.status === "under_review").length;
      const hold = users.filter((u) => u.status === "on_hold").length;
      const banned = users.filter((u) => u.status === "banned").length;
      return { total, approved, pending, review, hold, banned };
    } else {
      const total = users.length;
      const active = users.filter((u) => u.isActive).length;
      const inactive = users.filter((u) => !u.isActive).length;
      return { total, active, inactive };
    }
  };
  const stats = getStats();

  const formatDateUS = (ts) => {
    try {
      const date = ts?.toDate ? ts.toDate() : new Date(ts);
      return date.toLocaleString("en-US", {
        month: "2-digit",
        day: "2-digit",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        hour12: true,
      });
    } catch {
      return "—";
    }
  };

  // === Redirection profil complet ===
  const handleViewProfile = (user) => {
    if (userType === "drivers") navigate(`/driver/${user.id}`);
    else navigate(`/sender/${user.id}`);
  };

  return (
    <div style={layout.container}>
      <Sidebar />
      <main style={layout.main}>
        {/* HEADER */}
        <div style={styles.header}>
          <h1 style={styles.pageTitle}>
            All {userType === "drivers" ? "Drivers" : "Senders"}
          </h1>
          <div style={styles.headerControls}>
            <button
              onClick={() =>
                setUserType(userType === "drivers" ? "senders" : "drivers")
              }
              style={styles.switchBtn}
            >
              Switch to {userType === "drivers" ? "Senders" : "Drivers"}
            </button>
            <input
              type="text"
              placeholder="Search by name or email"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              style={styles.searchInput}
            />
          </div>
        </div>

        {/* STATS */}
        <div style={styles.statsBar}>
          {userType === "drivers" ? (
            <>
              <span style={styles.stat}>Total: {stats.total}</span>
              <span style={{ ...styles.stat, color: "#16A34A" }}>
                Approved: {stats.approved}
              </span>
              <span style={{ ...styles.stat, color: "#F59E0B" }}>
                Pending: {stats.pending}
              </span>
              <span style={{ ...styles.stat, color: "#2563EB" }}>
                Under Review: {stats.review}
              </span>
              <span style={{ ...styles.stat, color: "#D97706" }}>
                On Hold: {stats.hold}
              </span>
              <span style={{ ...styles.stat, color: "#DC2626" }}>
                Banned: {stats.banned}
              </span>
            </>
          ) : (
            <>
              <span style={styles.stat}>Total: {stats.total}</span>
              <span style={{ ...styles.stat, color: "#16A34A" }}>
                Active: {stats.active}
              </span>
              <span style={{ ...styles.stat, color: "#DC2626" }}>
                Inactive: {stats.inactive}
              </span>
            </>
          )}
        </div>

        {/* TABLE + PANEL */}
        <div style={styles.contentWrapper}>
          {/* TABLE */}
          <div ref={tableRef} style={styles.tableCard}>
            <table style={styles.table}>
              <thead>
                <tr>
                  <th style={{ ...styles.th, width: "160px" }}>Full Name</th>
                  <th style={{ ...styles.th, width: "220px" }}>Email</th>
                  <th style={{ ...styles.th, width: "110px" }}>Status</th>
                  <th style={{ ...styles.th, width: "130px" }}>Registered</th>
                  <th style={{ ...styles.th, width: "90px" }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {currentUsers.length > 0 ? (
                  currentUsers.map((user, i) => (
                    <tr
                      key={user.id}
                      onClick={() => setSelectedUser(user)}
                      style={{
                        backgroundColor:
                          selectedUser?.id === user.id
                            ? "#E0F0FF"
                            : i % 2 === 0
                            ? "#FFFFFF"
                            : "#F9FAFB",
                        transition: "background-color 0.2s",
                        cursor: "pointer",
                      }}
                      onMouseEnter={(e) =>
                        (e.currentTarget.style.backgroundColor = "#EEF2FF")
                      }
                      onMouseLeave={(e) =>
                        (e.currentTarget.style.backgroundColor =
                          selectedUser?.id === user.id
                            ? "#E0F0FF"
                            : i % 2 === 0
                            ? "#FFFFFF"
                            : "#F9FAFB")
                      }
                    >
                      <td style={styles.td}>
                        {user.fullName || user.name || "—"}
                      </td>
                      <td style={styles.td}>{user.email || "—"}</td>
                      <td
                        style={{
                          ...styles.td,
                          fontWeight: 600,
                          color: getStatusColor(user),
                        }}
                      >
                        {userType === "drivers"
                          ? user.status || "pending"
                          : user.isActive
                          ? "Active"
                          : "Inactive"}
                      </td>
                      <td style={styles.td}>
                        {formatDateUS(user.createdAt || user.created_at)}
                      </td>
                      <td style={styles.td}>
                        <div
                          style={{
                            display: "flex",
                            justifyContent: "center",
                          }}
                        >
                          <button
                            style={styles.iconBtn}
                            onClick={(e) => {
                              e.stopPropagation();
                              handleViewProfile(user);
                            }}
                          >
                            <FiEye />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="5" style={styles.noData}>
                      No users found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>

            {/* Pagination */}
            <div style={styles.pagination}>
              <button
                onClick={prevPage}
                disabled={page === 1}
                style={{
                  ...styles.pageBtn,
                  opacity: page === 1 ? 0.5 : 1,
                }}
              >
                ◀
              </button>
              <span style={styles.pageInfo}>
                Page {page} / {totalPages || 1}
              </span>
              <button
                onClick={nextPage}
                disabled={page === totalPages}
                style={{
                  ...styles.pageBtn,
                  opacity: page === totalPages ? 0.5 : 1,
                }}
              >
                ▶
              </button>
            </div>
          </div>

          {/* DETAILS PANEL */}
          <div style={styles.detailsPanel}>
            {selectedUser ? (
              <div style={styles.detailsCard}>
                <div style={styles.photoWrapper}>
                  {selectedUser.photoUrl ? (
                    <img
                      src={selectedUser.photoUrl}
                      alt="Profile"
                      style={styles.photo}
                    />
                  ) : (
                    <div style={styles.photoPlaceholder}>No Photo</div>
                  )}
                </div>

                <h3 style={styles.userName}>
                  {selectedUser.fullName || selectedUser.name || "—"}
                </h3>
                <p style={styles.userEmail}>{selectedUser.email || "—"}</p>

                <div style={styles.infoBlock}>
                  <p>
                    <strong>Status:</strong>{" "}
                    <span
                      style={{
                        color: getStatusColor(selectedUser),
                        fontWeight: 600,
                      }}
                    >
                      {selectedUser.status ||
                        (selectedUser.isActive ? "Active" : "Inactive")}
                    </span>
                  </p>

                  {userType === "drivers" ? (
                    <>
                      <p>
                        <strong>Active:</strong>{" "}
                        {selectedUser.isAvailable ? "Online" : "Offline"}
                      </p>
                      <p>
                        <strong>Address:</strong>{" "}
                        {addressData
                          ? `${addressData.street || ""}, ${addressData.city || ""}, ${addressData.state || ""} ${addressData.zip || ""}`
                          : "—"}
                      </p>
                      <p>
                        <strong>Country:</strong>{" "}
                        {addressData?.country || "—"}
                      </p>
                      <p>
                        <strong>Registered:</strong>{" "}
                        {formatDateUS(
                          addressData?.created_at ||
                            selectedUser.created_at
                        )}
                      </p>
                    </>
                  ) : (
                    <>
                      <p>
                        <strong>Phone:</strong>{" "}
                        {selectedUser.senderPhone ||
                          selectedUser.phone ||
                          "—"}
                      </p>
                      <p>
                        <strong>Address:</strong>{" "}
                        {[selectedUser.street, selectedUser.city, selectedUser.state]
                          .filter(Boolean)
                          .join(", ") || "—"}
                      </p>
                      <p>
                        <strong>Country:</strong>{" "}
                        {selectedUser.country || "—"}
                      </p>
                      <p>
                        <strong>Registered:</strong>{" "}
                        {formatDateUS(selectedUser.createdAt)}
                      </p>
                    </>
                  )}
                </div>
              </div>
            ) : (
              <div style={styles.emptyPanel}>
                <p style={{ color: "#9CA3AF" }}>
                  Select a {userType === "drivers" ? "driver" : "sender"} to
                  view details.
                </p>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

/* === STYLES === */
const layout = {
  container: {
    display: "flex",
    backgroundColor: "#F9FAFB",
    fontFamily: "Inter, sans-serif",
    color: "#374151",
    minHeight: "100vh",
  },
  main: {
    flexGrow: 1,
    padding: 32,
    marginLeft: "var(--sidebar-width)",
  },
};

const styles = {
  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    flexWrap: "wrap",
    gap: 16,
    marginBottom: 16,
    paddingTop: "30px",
  },
  pageTitle: { fontSize: 26, fontWeight: 700 },
  headerControls: { display: "flex", gap: 10, alignItems: "center" },
  switchBtn: {
    padding: "6px 12px",
    backgroundColor: "#5B21B6",
    color: "#fff",
    border: "none",
    borderRadius: 6,
    cursor: "pointer",
    fontWeight: 600,
  },
  searchInput: {
    padding: "6px 12px",
    border: "1px solid #E5E7EB",
    borderRadius: 6,
    background: "#fff",
    width: 220,
  },
  statsBar: {
    display: "flex",
    flexWrap: "wrap",
    gap: 16,
    backgroundColor: "#fff",
    border: "1px solid #E5E7EB",
    padding: "10px 16px",
    borderRadius: 8,
    marginBottom: 16,
  },
  stat: { fontSize: 14, color: "#374151", fontWeight: 600 },
  contentWrapper: { display: "flex", gap: 20 },
  tableCard: {
    flex: 1.6,
    background: "#fff",
    border: "1px solid #E5E7EB",
    borderRadius: 12,
    padding: 20,
  },
  table: {
    width: "100%",
    borderCollapse: "collapse",
    tableLayout: "fixed",
  },
  th: {
    border: "1px solid #E5E7EB",
    padding: "12px",
    textAlign: "left",
    background: "#5B21B6",
    fontSize: "14px",
    fontWeight: 600,
    color: "#fff",
  },
  td: {
    border: "1px solid #E5E7EB",
    padding: "12px",
    fontSize: "14px",
    color: "#374151",
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
    height: "48px",
  },
  iconBtn: {
    background: "transparent",
    border: "none",
    cursor: "pointer",
    fontSize: 18,
    color: "#374151",
  },
  noData: { textAlign: "center", color: "#6B7280", padding: 16 },
  pagination: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    gap: 12,
    marginTop: 12,
  },
  pageBtn: {
    padding: "6px 10px",
    background: "#5B21B6",
    color: "#fff",
    border: "none",
    borderRadius: 6,
  },
  pageInfo: { fontWeight: 600 },
  detailsPanel: {
    flex: 1,
    background: "#fff",
    border: "1px solid #E5E7EB",
    borderRadius: 12,
    padding: 20,
  },
  detailsCard: { display: "flex", flexDirection: "column", alignItems: "center" },
  photoWrapper: {
    width: "160px",
    height: "200px",
    background: "#E5E7EB",
    borderRadius: 8,
    overflow: "hidden",
  },
  photo: { width: "100%", height: "100%", objectFit: "cover" },
  photoPlaceholder: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    height: "100%",
    color: "#9CA3AF",
  },
  userName: { fontWeight: 700, fontSize: 18, marginTop: 10 },
  userEmail: { fontSize: 14, color: "#6B7280", marginBottom: 10 },
  infoBlock: { textAlign: "left", width: "100%", marginTop: 10 },
  emptyPanel: {
    height: "100%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
};
