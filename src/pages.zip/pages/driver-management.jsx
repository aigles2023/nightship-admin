import React, { useEffect, useState } from "react";
import { db } from "../firebase/config";
import {
  collection,
  onSnapshot,
  doc,
  updateDoc,
  getDoc,
} from "firebase/firestore";
import { getAuth } from "firebase/auth";

export default function DriverManagement() {
  const auth = getAuth();
  const [userRole, setUserRole] = useState(null);
  const [drivers, setDrivers] = useState([]);
  const [selectedDriver, setSelectedDriver] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [activeTab, setActiveTab] = useState("pending");

  // --- Get connected user's role
  useEffect(() => {
    const user = auth.currentUser;
    if (!user) return;
    const fetchRole = async () => {
      const roleDoc = await getDoc(doc(db, "users", user.uid));
      if (roleDoc.exists()) {
        setUserRole(roleDoc.data().role || "CS");
      } else {
        setUserRole("CS");
      }
    };
    fetchRole();
  }, [auth]);

  // --- Real-time drivers data
  useEffect(() => {
    const unsub = onSnapshot(collection(db, "drivers"), (snap) => {
      const list = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      setDrivers(list);
    });
    return () => unsub();
  }, []);

  // --- Actions
  const sendForManagerReview = async (id) => {
    try {
      await updateDoc(doc(db, "drivers", id), {
        status: "under_review",
        reviewedBy: auth.currentUser.uid,
        reviewedAt: new Date(),
      });
      alert("✅ Driver escalated to Manager for review.");
    } catch (err) {
      console.error(err);
      alert("❌ Failed to update status.");
    }
  };

  const approveDriver = async (id) => {
    try {
      await updateDoc(doc(db, "drivers", id), {
        status: "approved",
        isApproved: true,
        approvedBy: auth.currentUser.uid,
        approvedAt: new Date(),
      });
      alert("✅ Driver approved successfully.");
    } catch (err) {
      console.error(err);
      alert("❌ Error while approving driver.");
    }
  };

  const rejectDriver = async (id) => {
    try {
      await updateDoc(doc(db, "drivers", id), {
        status: "rejected",
        isApproved: false,
        rejectedBy: auth.currentUser.uid,
        rejectedAt: new Date(),
      });
      alert("🚫 Driver marked as rejected.");
    } catch (err) {
      console.error(err);
      alert("❌ Error rejecting driver.");
    }
  };

  /**
   * Handle approval or rejection for specific sections (personal, contact,
   * license, vehicle, documents).  Updates the corresponding status field
   * in the driver document.  For example, approving the personal info
   * updates `personalStatus: 'approved'`, whereas rejecting sets
   * `personalStatus: 'needs_attention'`.
   */
  const handleFieldAction = async (driverId, fieldKey, action) => {
    const newStatus = action === 'approve' ? 'approved' : 'needs_attention';
    try {
      if (fieldKey === 'documents') {
        // For documents, update each document status (registration, insurance, etc.)
        const driverRef = doc(db, 'drivers', driverId);
        const updates = {};
        const snap = await getDoc(driverRef);
        if (snap.exists()) {
          const docs = snap.data().documents || {};
          Object.keys(docs).forEach((key) => {
            updates[`${key}Status`] = newStatus;
          });
        }
        await updateDoc(driverRef, updates);
      } else {
        const statusField = `${fieldKey}Status`;
        await updateDoc(doc(db, 'drivers', driverId), { [statusField]: newStatus });
      }
      alert(
        action === 'approve'
          ? `✅ ${fieldKey.charAt(0).toUpperCase() + fieldKey.slice(1)} approved`
          : `⚠️ ${fieldKey.charAt(0).toUpperCase() + fieldKey.slice(1)} flagged for review`,
      );
    } catch (err) {
      console.error(err);
      alert('❌ Failed to update status');
    }
  };

  // --- Styles
  const pageStyle = {
    marginLeft: "var(--sidebar-width)",
    marginTop: "85px",
    padding: "40px",
    backgroundColor: "#F9FAFB",
    minHeight: "100vh",
    fontFamily: "Inter, sans-serif",
    marginRight: "400px", // leave space for the right panel
  };

  const gridStyle = {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
    gap: 20,
    marginTop: 16,
  };

  const cardStyle = {
    border: "1px solid #E5E7EB",
    borderRadius: 12,
    padding: 20,
    backgroundColor: "#FFFFFF",
    boxShadow: "0 2px 6px rgba(0,0,0,0.05)",
    display: "flex",
    flexDirection: "column",
    gap: 12,
    transition: "all 0.3s ease",
  };

  const btnStyle = {
    backgroundColor: "#4F46E5",
    color: "#fff",
    border: "none",
    borderRadius: 6,
    padding: "8px 12px",
    cursor: "pointer",
    fontSize: 14,
    transition: "background 0.2s ease",
  };

  const Avatar = ({ driver }) => {
    const size = 50;
    if (driver.photoURL) {
      return (
        <img
          src={driver.photoURL}
          alt={driver.fullName || "Driver"}
          style={{
            width: size,
            height: size,
            borderRadius: "50%",
            objectFit: "cover",
          }}
        />
      );
    }
    const initial = (driver.fullName?.[0] || "D").toUpperCase();
    return (
      <div
        style={{
          width: size,
          height: size,
          borderRadius: "50%",
          backgroundColor: "#E5E7EB",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontWeight: 600,
          color: "#6B7280",
        }}
      >
        {initial}
      </div>
    );
  };

  // --- Modal for document review
  const ReviewModal = ({ driver }) => {
    if (!driver) return null;
    const docs = driver.documents || {};

    return (
      <div
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          backgroundColor: "rgba(0,0,0,0.4)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          zIndex: 999,
        }}
        onClick={() => setShowModal(false)}
      >
        <div
          style={{
            width: "500px",
            backgroundColor: "#fff",
            borderRadius: 12,
            padding: 24,
            boxShadow: "0 5px 15px rgba(0,0,0,0.3)",
          }}
          onClick={(e) => e.stopPropagation()}
        >
          <h3 style={{ marginBottom: 16, fontSize: 18, fontWeight: 600 }}>
            Review Documents
          </h3>
          {Object.keys(docs).length === 0 ? (
            <p>No documents uploaded yet.</p>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {Object.entries(docs).map(([key, url]) => (
                <a
                  key={key}
                  href={url}
                  target="_blank"
                  rel="noreferrer"
                  style={{ color: "#4F46E5", textDecoration: "underline" }}
                >
                  📎 {key}
                </a>
              ))}
            </div>
          )}
          <div style={{ marginTop: 24, display: "flex", gap: 10 }}>
            {userRole === "CS" && (
              <>
                <button
                  style={btnStyle}
                  onClick={() => {
                    sendForManagerReview(driver.id);
                    setShowModal(false);
                  }}
                >
                  Send for Manager Review
                </button>
                <button
                  style={{ ...btnStyle, backgroundColor: "#DC2626" }}
                  onClick={() => {
                    rejectDriver(driver.id);
                    setShowModal(false);
                  }}
                >
                  Reject
                </button>
              </>
            )}
            {userRole === "Manager" && (
              <button
                style={{ ...btnStyle, backgroundColor: "#16A34A" }}
                onClick={() => {
                  approveDriver(driver.id);
                  setShowModal(false);
                }}
              >
                Approve Driver
              </button>
            )}
            <button
              style={{ ...btnStyle, backgroundColor: "#9CA3AF" }}
              onClick={() => setShowModal(false)}
            >
              Close
            </button>
          </div>
        </div>
      </div>
    );
  };

  // --- Details panel for selected driver
  const DriverDetails = ({ driver }) => {
    if (!driver) return null;
    // Helper to format address nicely (handles both string and object)
    const formatAddress = (addr) => {
      if (!addr) return '';
      if (typeof addr === 'string') return addr;
      const parts = [addr.street, addr.city, addr.state, addr.zip].filter(Boolean);
      return parts.join(', ');
    };
    const docs = driver.documents || {};
    // Compute license status (active or expired)
    let licenseStatus = '';
    if (driver.license && driver.license.expiration) {
      const expParts = String(driver.license.expiration).split(/[\/-]/);
      if (expParts.length === 3) {
        const [mm, dd, yy] = expParts;
        const year = yy.length === 2 ? '20' + yy : yy;
        const expDate = new Date(parseInt(year, 10), parseInt(mm, 10) - 1, parseInt(dd, 10));
        licenseStatus = expDate >= new Date() ? 'Active' : 'Expired';
      }
    }
    return (
      <div
        style={{
          backgroundColor: '#fff',
          border: '1px solid #E5E7EB',
          borderRadius: 12,
          padding: 24,
          boxShadow: '0 2px 6px rgba(0,0,0,0.05)',
          marginTop: 20,
        }}
      >
        <div style={{ marginBottom: 20 }}>
          <h3 style={{ fontSize: 20, fontWeight: 700, marginBottom: 8 }}>
            {driver.fullName || driver.name || 'Unnamed'}
          </h3>
          <span style={{ fontSize: 14, color: '#6B7280' }}>
            Account created on{' '}
            {driver.createdAt
              ? new Date(driver.createdAt).toLocaleDateString()
              : '—'}
          </span>
        </div>
        {/* Personal and DOB */}
        <div style={{ marginBottom: 20 }}>
          <h4 style={{ fontSize: 16, fontWeight: 600, marginBottom: 6 }}>Name & DOB</h4>
          <p style={{ margin: '4px 0' }}>
            <b>Full Name:</b> {driver.name || driver.fullName || '—'}
          </p>
          <p style={{ margin: '4px 0' }}>
            <b>Date of Birth:</b> {driver.dob || '—'}
          </p>
          <div style={{ marginTop: 8, display: 'flex', gap: 8 }}>
            <button
              style={{ ...btnStyle, backgroundColor: '#16A34A' }}
              onClick={() => handleFieldAction(driver.id, 'personal', 'approve')}
            >
              Approve
            </button>
            <button
              style={{ ...btnStyle, backgroundColor: '#DC2626' }}
              onClick={() => handleFieldAction(driver.id, 'personal', 'reject')}
            >
              Reject
            </button>
          </div>
        </div>
        {/* Contact details */}
        <div style={{ marginBottom: 20 }}>
          <h4 style={{ fontSize: 16, fontWeight: 600, marginBottom: 6 }}>Contact Details</h4>
          <p style={{ margin: '4px 0' }}>
            <b>Email:</b> {driver.email || '—'}
          </p>
          <p style={{ margin: '4px 0' }}>
            <b>Phone:</b> {driver.phone || '—'}
          </p>
          <p style={{ margin: '4px 0' }}>
            <b>Address:</b> {formatAddress(driver.address) || '—'}
          </p>
          <div style={{ marginTop: 8, display: 'flex', gap: 8 }}>
            <button
              style={{ ...btnStyle, backgroundColor: '#16A34A' }}
              onClick={() => handleFieldAction(driver.id, 'contact', 'approve')}
            >
              Approve
            </button>
            <button
              style={{ ...btnStyle, backgroundColor: '#DC2626' }}
              onClick={() => handleFieldAction(driver.id, 'contact', 'reject')}
            >
              Reject
            </button>
          </div>
        </div>
        {/* Driver license */}
        <div style={{ marginBottom: 20 }}>
          <h4 style={{ fontSize: 16, fontWeight: 600, marginBottom: 6 }}>Driver License</h4>
          {driver.license ? (
            <>
              <p style={{ margin: '4px 0' }}>
                <b>Number:</b> {driver.license.number || '—'}
              </p>
              <p style={{ margin: '4px 0' }}>
                <b>State:</b> {driver.license.state || '—'}
              </p>
              <p style={{ margin: '4px 0' }}>
                <b>Expiration:</b> {driver.license.expiration || '—'}
                {licenseStatus && (
                  <span style={{ marginLeft: 8, color: licenseStatus === 'Active' ? '#16A34A' : '#DC2626', fontWeight: 600 }}>
                    ({licenseStatus})
                  </span>
                )}
              </p>
            </>
          ) : (
            <p style={{ margin: '4px 0', fontStyle: 'italic' }}>No license info</p>
          )}
          <div style={{ marginTop: 8, display: 'flex', gap: 8 }}>
            <button
              style={{ ...btnStyle, backgroundColor: '#16A34A' }}
              onClick={() => handleFieldAction(driver.id, 'license', 'approve')}
            >
              Approve
            </button>
            <button
              style={{ ...btnStyle, backgroundColor: '#DC2626' }}
              onClick={() => handleFieldAction(driver.id, 'license', 'reject')}
            >
              Reject
            </button>
          </div>
        </div>
        {/* Vehicle information */}
        <div style={{ marginBottom: 20 }}>
          <h4 style={{ fontSize: 16, fontWeight: 600, marginBottom: 6 }}>Vehicle Information</h4>
          {driver.vehicle ? (
            <>
              <p style={{ margin: '4px 0' }}>
                <b>Brand:</b> {driver.vehicle.brand || '—'}
              </p>
              <p style={{ margin: '4px 0' }}>
                <b>Make:</b> {driver.vehicle.make || '—'}
              </p>
              <p style={{ margin: '4px 0' }}>
                <b>Year:</b> {driver.vehicle.year || '—'}
              </p>
              <p style={{ margin: '4px 0' }}>
                <b>Color:</b> {driver.vehicle.color || '—'}
              </p>
              <p style={{ margin: '4px 0' }}>
                <b>Plate:</b> {driver.vehicle.plate || '—'}
              </p>
              <p style={{ margin: '4px 0' }}>
                <b>State:</b> {driver.vehicle.state || '—'}
              </p>
            </>
          ) : (
            <p style={{ margin: '4px 0', fontStyle: 'italic' }}>No vehicle info</p>
          )}
          <div style={{ marginTop: 8, display: 'flex', gap: 8 }}>
            <button
              style={{ ...btnStyle, backgroundColor: '#16A34A' }}
              onClick={() => handleFieldAction(driver.id, 'vehicle', 'approve')}
            >
              Approve
            </button>
            <button
              style={{ ...btnStyle, backgroundColor: '#DC2626' }}
              onClick={() => handleFieldAction(driver.id, 'vehicle', 'reject')}
            >
              Reject
            </button>
          </div>
        </div>
        {/* Uploaded documents */}
        <div style={{ marginBottom: 20 }}>
          <h4 style={{ fontSize: 16, fontWeight: 600, marginBottom: 6 }}>Uploaded Documents</h4>
          {Object.keys(docs).length === 0 ? (
            <p style={{ fontStyle: 'italic' }}>No documents uploaded</p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {Object.entries(docs).map(([key, url]) => (
                <div key={key} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ width: 120, fontWeight: 600, textTransform: 'capitalize' }}>
                    {key.replace(/([A-Z])/g, ' $1')}
                  </span>
                  {url ? (
                    <>
                      <a
                        href={url}
                        target="_blank"
                        rel="noreferrer"
                        style={{ color: '#2563EB', textDecoration: 'underline' }}
                      >
                        View
                      </a>
                      <a
                        href={url}
                        download
                        style={{ color: '#2563EB', textDecoration: 'underline' }}
                      >
                        Download
                      </a>
                    </>
                  ) : (
                    <span style={{ color: '#DC2626' }}>Missing</span>
                  )}
                </div>
              ))}
            </div>
          )}
          <div style={{ marginTop: 8, display: 'flex', gap: 8 }}>
            {/* Approve/reject documents as a whole (registration/insurance) */}
            <button
              style={{ ...btnStyle, backgroundColor: '#16A34A' }}
              onClick={() => handleFieldAction(driver.id, 'documents', 'approve')}
            >
              Approve
            </button>
            <button
              style={{ ...btnStyle, backgroundColor: '#DC2626' }}
              onClick={() => handleFieldAction(driver.id, 'documents', 'reject')}
            >
              Reject
            </button>
          </div>
        </div>
        {/* Bottom action panel */}
        <div
          style={{
            borderTop: '1px solid #E5E7EB',
            paddingTop: 16,
            display: 'flex',
            gap: 12,
            flexWrap: 'wrap',
          }}
        >
          {userRole === 'CS' && driver.status !== 'approved' && (
            <>
              <button
                style={{ ...btnStyle, backgroundColor: '#6B7280' }}
                onClick={() => {
                  const ok = window.confirm(
                    'Have you reviewed all documents and compared them with the provided information?'
                  );
                  if (ok) {
                    alert('Driver review completed');
                  }
                }}
              >
                Review Driver
              </button>
              <button
                style={{ ...btnStyle, backgroundColor: '#16A34A' }}
                onClick={() => {
                  const ok = window.confirm('Approve this driver?');
                  if (ok) approveDriver(driver.id);
                }}
              >
                Approve Driver
              </button>
              <button
                style={{ ...btnStyle, backgroundColor: '#2563EB' }}
                onClick={() => {
                  const ok = window.confirm('Send for Manager review?');
                  if (ok) sendForManagerReview(driver.id);
                }}
              >
                Send to Manager
              </button>
              <button
                style={{ ...btnStyle, backgroundColor: '#DC2626' }}
                onClick={() => {
                  const ok = window.confirm('Reject this driver?');
                  if (ok) rejectDriver(driver.id);
                }}
              >
                Reject Driver
              </button>
            </>
          )}
          {userRole === 'Manager' && driver.status === 'under_review' && (
            <button
              style={{ ...btnStyle, backgroundColor: '#16A34A' }}
              onClick={() => {
                const ok = window.confirm('Approve this driver?');
                if (ok) approveDriver(driver.id);
              }}
            >
              Approve Driver
            </button>
          )}
        </div>
      </div>
    );
  };

  // --- Counters for tabs
  const counts = {
    pending: drivers.filter((d) => d.status === "pending").length,
    under_review: drivers.filter((d) => d.status === "under_review").length,
    approved: drivers.filter((d) => d.status === "approved").length,
    rejected: drivers.filter((d) => d.status === "rejected").length,
  };

  // --- Filtered list by active tab
  const filteredList = drivers.filter((d) => {
    if (activeTab === "pending") return d.status === "pending";
    if (activeTab === "waiting") return d.status === "under_review";
    if (activeTab === "approved") return d.status === "approved";
    if (activeTab === "rejected") return d.status === "rejected";
    return true;
  });

  // --- Right panel styles
  const rightPanelStyle = {
    position: "fixed",
    right: 0,
    top: "85px",
    width: "360px",
    height: "calc(100vh - 85px)",
    backgroundColor: "#FFFFFF",
    borderLeft: "1px solid #E5E7EB",
    boxShadow: "-2px 0 6px rgba(0,0,0,0.05)",
    padding: "20px",
    overflowY: "auto",
    zIndex: 50,
    transition: "all 0.3s ease",
  };

  return (
    <>
      {/* LEFT MAIN AREA */}
      <div style={pageStyle}>
        <h2 style={{ fontSize: 24, fontWeight: 700, marginBottom: 20 }}>
          Driver Management
        </h2>
        {/* Show details of the selected driver or a placeholder */}
        {selectedDriver ? (
          <DriverDetails driver={selectedDriver} />
        ) : (
          <p style={{ color: '#6B7280', fontStyle: 'italic' }}>
            Select a driver from the list to view details.
          </p>
        )}
        {/* If a review modal is triggered, overlay on top */}
        {showModal && <ReviewModal driver={selectedDriver} />}
      </div>

      {/* RIGHT FIXED PANEL */}
      <div style={rightPanelStyle}>
        <h3
          style={{
            fontSize: 18,
            fontWeight: 700,
            marginBottom: 12,
            paddingBottom: 8,
            borderBottom: '1px solid #E5E7EB',
          }}
        >
          Current Drivers
        </h3>

        {/* Tabs */}
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            marginBottom: 12,
            flexWrap: "wrap",
            gap: 8,
          }}
        >
          {[
            { key: "pending", label: "Pending", color: "#16A34A" },
            {
              key: "waiting",
              label: "Waiting for approval",
              color: "#2563EB",
              hidden: counts.under_review === 0,
            },
            { key: "approved", label: "Approved", color: "#1D4ED8" },
            { key: "rejected", label: "Rejected", color: "#DC2626" },
          ]
            .filter((t) => !t.hidden)
            .map((tab) => (
              <div
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                style={{
                  cursor: "pointer",
                  fontSize: 13,
                  fontWeight: 600,
                  padding: "6px 10px",
                  borderRadius: 8,
                  backgroundColor:
                    activeTab === tab.key ? `${tab.color}22` : "#F3F4F6",
                  color: activeTab === tab.key ? tab.color : "#374151",
                  transition: "all 0.3s ease",
                  display: "flex",
                  alignItems: "center",
                  gap: 6,
                }}
              >
                {tab.label}
                {tab.key === "pending" && counts.pending > 0 && (
                  <span
                    style={{
                      backgroundColor: "#16A34A",
                      color: "#fff",
                      fontSize: 11,
                      fontWeight: 700,
                      borderRadius: "50%",
                      width: 18,
                      height: 18,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    {counts.pending}
                  </span>
                )}
                {tab.key === "rejected" && counts.rejected > 0 && (
                  <span
                    style={{
                      backgroundColor: "#DC2626",
                      color: "#fff",
                      fontSize: 11,
                      fontWeight: 700,
                      borderRadius: "50%",
                      width: 18,
                      height: 18,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    {counts.rejected}
                  </span>
                )}
              </div>
            ))}
        </div>

        {/* Scrollable list */}
        <div style={{ maxHeight: "calc(100vh - 200px)", overflowY: "auto" }}>
          {filteredList.length === 0 ? (
            <p style={{ color: "#9CA3AF", fontSize: 13, marginTop: 10 }}>
              No drivers in this category.
            </p>
          ) : (
            filteredList.slice(0, 20).map((driver) => (
              <div
                key={driver.id}
                onClick={() => {
                  // Select the driver and show details on the left panel. Do not
                  // automatically open the modal; the details pane includes actions.
                  setSelectedDriver(driver);
                  setShowModal(false);
                }}
                style={{
                  border: "1px solid #E5E7EB",
                  borderRadius: 10,
                  padding: "10px 12px",
                  marginBottom: 10,
                  backgroundColor: "#F9FAFB",
                  cursor: "pointer",
                  transition: "all 0.3s ease",
                }}
                onMouseEnter={(e) =>
                  (e.currentTarget.style.transform = "scale(1.02)")
                }
                onMouseLeave={(e) =>
                  (e.currentTarget.style.transform = "scale(1)")
                }
              >
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                  }}
                >
                  <b style={{ fontSize: 14 }}>
                    {driver.fullName || "Unnamed"}
                  </b>
                  <span style={{ fontSize: 12, color: "#6B7280" }}>
                    {driver.createdAt
                      ? new Date(driver.createdAt).toLocaleDateString()
                      : ""}
                  </span>
                </div>
                <div
                  style={{
                    fontStyle: "italic",
                    fontSize: 12,
                    color: "#6B7280",
                    marginTop: 4,
                  }}
                >
                  Driver • Details →
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </>
  );
}
