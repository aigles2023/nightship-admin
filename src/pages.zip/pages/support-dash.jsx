import React, { useEffect, useState, useRef } from "react";
import Sidebar from "../components/sidebar";
import {
  collection,
  addDoc,
  doc,
  setDoc,
  onSnapshot,
  serverTimestamp,
  query,
  orderBy,
} from "firebase/firestore";
import { db } from "../firebase/config";

export default function SupportDash() {
  const [activeTab, setActiveTab] = useState("inbox");
  const [threads, setThreads] = useState([]);
  const [selectedThread, setSelectedThread] = useState(null);

  useEffect(() => {
    const q = query(collection(db, "support_threads"), orderBy("updatedAt", "desc"));
    const unsub = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
      setThreads(data);
    });
    return () => unsub();
  }, []);

  return (
    <div style={styles.container}>
      <Sidebar />
      <main style={styles.main}>
        <h1 style={styles.title}>Support Messages</h1>

        <div style={styles.tabs}>
          <button
            onClick={() => setActiveTab("inbox")}
            style={tabStyle(activeTab === "inbox")}
          >
            Inbox
          </button>
          <button
            onClick={() => setActiveTab("newMessage")}
            style={tabStyle(activeTab === "newMessage")}
          >
            New Message
          </button>
        </div>

        {activeTab === "inbox" ? (
          <InboxView
            threads={threads}
            selectedThread={selectedThread}
            setSelectedThread={setSelectedThread}
          />
        ) : (
          <NewMessageView setActiveTab={setActiveTab} />
        )}
      </main>
    </div>
  );
}

/* ---------------- Inbox View ---------------- */
const InboxView = ({ threads, selectedThread, setSelectedThread }) => {
  const [messages, setMessages] = useState([]);
  const [messageText, setMessageText] = useState("");
  const chatBottomRef = useRef(null);

  useEffect(() => {
    if (!selectedThread) return;
    const q = query(
      collection(db, "support_threads", selectedThread.id, "messages"),
      orderBy("createdAt", "asc")
    );
    const unsub = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
      setMessages(data);
    });
    return () => unsub();
  }, [selectedThread]);

  useEffect(() => {
    if (chatBottomRef.current) {
      chatBottomRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const sendMessage = async () => {
    if (!selectedThread || !messageText.trim()) return;
    const msgRef = collection(db, "support_threads", selectedThread.id, "messages");
    await addDoc(msgRef, {
      senderId: "support_admin",
      senderType: "support",
      text: messageText.trim(),
      createdAt: serverTimestamp(),
    });
    await setDoc(
      doc(db, "support_threads", selectedThread.id),
      { lastMessage: messageText.trim(), updatedAt: serverTimestamp() },
      { merge: true }
    );
    setMessageText("");
  };

  const formatDate = (timestamp) => {
    if (!timestamp?.seconds) return "";
    return new Date(timestamp.seconds * 1000).toLocaleString("en-US", {
      month: "2-digit",
      day: "2-digit",
      year: "numeric",
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    });
  };

  return (
    <div style={inboxStyles.wrapper}>
      {/* Bloc gauche */}
      <div style={inboxStyles.sidebar}>
        {threads.length === 0 ? (
          <p style={styles.noData}>No messages yet.</p>
        ) : (
          threads.map((t) => (
            <div
              key={t.id}
              onClick={() => setSelectedThread(t)}
              style={{
                ...inboxStyles.threadItem,
                backgroundColor: selectedThread?.id === t.id ? "#EDE9FE" : "#fff",
              }}
            >
              <p style={inboxStyles.subject}>{t.subject || "No subject"}</p>
              <strong>{t.targetName || "Unnamed"}</strong>
              <p style={inboxStyles.email}>{t.targetEmail || ""}</p>
              {t.updatedAt && (
                <p style={inboxStyles.date}>{formatDate(t.updatedAt)}</p>
              )}
            </div>
          ))
        )}
      </div>

      {/* Bloc droite */}
      <div style={inboxStyles.detail}>
        {!selectedThread ? (
          <p style={styles.noData}>Select a conversation to view details.</p>
        ) : (
          <>
            {/* En-tête */}
            <div style={inboxStyles.detailHeader}>
              {selectedThread.targetPhoto ||
              selectedThread.photoUrl ||
              selectedThread.photoURL ||
              selectedThread.profileImage ? (
                <img
                  src={
                    selectedThread.targetPhoto ||
                    selectedThread.photoUrl ||
                    selectedThread.photoURL ||
                    selectedThread.profileImage
                  }
                  alt="Profile"
                  style={inboxStyles.avatar}
                />
              ) : (
                <div style={inboxStyles.avatarPlaceholder}>
                  {selectedThread.targetName
                    ? selectedThread.targetName[0].toUpperCase()
                    : "?"}
                </div>
              )}

              <h3 style={inboxStyles.subjectHeader}>
                {selectedThread.subject || "No subject"}
              </h3>
              <p style={inboxStyles.userName}>{selectedThread.targetName}</p>
              <p style={inboxStyles.role}>
                {selectedThread.targetRole || "Driver"}
              </p>
              <p style={inboxStyles.userEmail}>
                {selectedThread.targetEmail || ""}
              </p>
            </div>

            {/* Messages */}
            <div style={inboxStyles.messagesContainer}>
              {messages.map((m) => (
                <div
                  key={m.id}
                  style={
                    m.senderType === "support"
                      ? inboxStyles.msgBubbleRight
                      : inboxStyles.msgBubbleLeft
                  }
                >
                  <p style={inboxStyles.messageText}>{m.text}</p>
                  <span style={inboxStyles.timestamp}>
                    {formatDate(m.createdAt)}
                  </span>
                </div>
              ))}
              <div ref={chatBottomRef} />
            </div>

            {/* Zone de saisie */}
            <div style={inboxStyles.inputArea}>
              <textarea
                placeholder="Type your message..."
                value={messageText}
                onChange={(e) => setMessageText(e.target.value)}
                style={inboxStyles.input}
              />
              <button onClick={sendMessage} style={inboxStyles.sendBtn}>
                Send
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

/* ---------------- New Message ---------------- */
const NewMessageView = ({ setActiveTab }) => {
  const [drivers, setDrivers] = useState([]);
  const [senders, setSenders] = useState([]);
  const [target, setTarget] = useState("");
  const [targetName, setTargetName] = useState("");
  const [targetEmail, setTargetEmail] = useState("");
  const [targetPhoto, setTargetPhoto] = useState("");
  const [targetRole, setTargetRole] = useState("");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");

  useEffect(() => {
    const unsubDrivers = onSnapshot(collection(db, "drivers"), (snap) =>
      setDrivers(snap.docs.map((d) => ({ id: d.id, ...d.data() })))
    );
    const unsubSenders = onSnapshot(collection(db, "senders"), (snap) =>
      setSenders(snap.docs.map((d) => ({ id: d.id, ...d.data() })))
    );
    return () => {
      unsubDrivers();
      unsubSenders();
    };
  }, []);

  const startMessage = async () => {
    if (!target || !message.trim() || !subject.trim()) return;

    const threadRef = doc(collection(db, "support_threads"));
    await setDoc(threadRef, {
      targetId: target,
      targetName,
      targetEmail,
      targetPhoto,
      targetRole,
      subject,
      participants: ["support_admin", target],
      lastMessage: message.trim(),
      updatedAt: serverTimestamp(),
    });

    await addDoc(collection(threadRef, "messages"), {
      senderId: "support_admin",
      senderType: "support",
      text: message.trim(),
      createdAt: serverTimestamp(),
    });

    setActiveTab("inbox");
  };

  return (
    <div style={emailStyles.form}>
      <select
        value={target}
        onChange={(e) => {
          const [id, name, email, role, photo] = e.target.value.split("|");
          setTarget(id);
          setTargetName(name);
          setTargetEmail(email);
          setTargetPhoto(photo);
          setTargetRole(role);
        }}
        style={emailStyles.input}
      >
        <option value="">Select recipient...</option>
        <optgroup label="Drivers">
          {drivers.map((d) => (
            <option
              key={d.id}
              value={`${d.id}|${d.fullName || d.name || "Unnamed"}|${d.email || ""}|Driver|${
                d.photoUrl || d.photoURL || ""
              }`}
            >
              {d.fullName || d.name || d.email}
            </option>
          ))}
        </optgroup>
        <optgroup label="Senders">
          {senders.map((s) => (
            <option
              key={s.id}
              value={`${s.id}|${s.fullName || s.name || "Unnamed"}|${s.email || ""}|Sender|${
                s.photoUrl || s.photoURL || ""
              }`}
            >
              {s.fullName || s.name || s.email}
            </option>
          ))}
        </optgroup>
      </select>

      <input
        type="text"
        placeholder="Subject"
        value={subject}
        onChange={(e) => setSubject(e.target.value)}
        style={emailStyles.input}
      />

      <textarea
        placeholder="Write your message..."
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        style={emailStyles.textarea}
      />

      <button onClick={startMessage} style={emailStyles.sendBtn}>
        Send Message
      </button>
    </div>
  );
};

/* ---------------- Styles ---------------- */
const tabStyle = (active) => ({
  padding: "10px 24px",
  marginRight: 10,
  backgroundColor: active ? "#5B21B6" : "#E5E7EB",
  color: active ? "#fff" : "#374151",
  border: "none",
  borderRadius: 8,
  cursor: "pointer",
  fontWeight: 600,
});

const styles = {
  container: { display: "flex", minHeight: "100vh", backgroundColor: "#F9FAFB" },
  main: {
    flexGrow: 1,
    padding: 32,
    marginTop: 30,
    marginLeft: "var(--sidebar-width)",
  },
  title: { fontSize: 26, fontWeight: 700, marginBottom: 20 },
  tabs: { display: "flex", gap: 10, marginBottom: 20 },
  noData: { color: "#9CA3AF", fontStyle: "italic", textAlign: "center" },
};

const inboxStyles = {
  wrapper: { display: "flex", gap: 20, height: 700 },
  sidebar: {
    width: "45%",
    backgroundColor: "#fff",
    borderRadius: 10,
    border: "1px solid #E5E7EB",
    overflowY: "auto",
    padding: 16,
  },
  threadItem: {
    border: "1px solid #E5E7EB",
    padding: "10px 12px",
    borderRadius: 8,
    cursor: "pointer",
    marginBottom: 10,
    transition: "background 0.2s",
  },
  subject: {
    fontWeight: 700,
    color: "#5B21B6",
    marginBottom: 4,
  },
  email: { fontStyle: "italic", color: "#6B7280", marginTop: 2, fontSize: 13 },
  date: { color: "#9CA3AF", fontSize: 12, marginTop: 2 },
  detail: {
    width: "55%",
    backgroundColor: "#fff",
    border: "1px solid #E5E7EB",
    borderRadius: 10,
    padding: 16,
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-between",
  },
  detailHeader: {
    textAlign: "center",
    borderBottom: "1px solid #E5E7EB",
    paddingBottom: 10,
    marginBottom: 10,
  },
  avatar: {
    width: 90,
    height: 90,
    borderRadius: "50%",
    objectFit: "cover",
    margin: "auto",
  },
  avatarPlaceholder: {
    width: 90,
    height: 90,
    borderRadius: "50%",
    backgroundColor: "#E5E7EB",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    fontSize: 36,
    color: "#4B5563",
    margin: "auto",
  },
  subjectHeader: {
    fontWeight: 700,
    color: "#5B21B6",
    marginTop: 10,
    fontSize: 18,
  },
  userName: { fontWeight: 600, marginTop: 4 },
  role: { color: "#6B7280", fontSize: 13 },
  userEmail: { fontStyle: "italic", color: "#6B7280" },
  messagesContainer: {
    flex: 1,
    overflowY: "auto",
    display: "flex",
    flexDirection: "column",
    gap: 8,
  },
  msgBubbleLeft: {
    backgroundColor: "#F3F4F6",
    color: "#111827",
    alignSelf: "flex-start",
    padding: 10,
    borderRadius: 10,
    maxWidth: "80%",
    boxShadow: "0px 1px 2px rgba(0,0,0,0.1)",
  },
  msgBubbleRight: {
    backgroundColor: "#E5E7EB",
    color: "#111827",
    alignSelf: "flex-end",
    padding: 10,
    borderRadius: 10,
    maxWidth: "80%",
    boxShadow: "0px 1px 2px rgba(0,0,0,0.1)",
  },
  messageText: { margin: 0, fontSize: 14, lineHeight: 1.4 },
  timestamp: { fontSize: 11, marginTop: 4, color: "#9CA3AF", display: "block" },
  inputArea: {
    display: "flex",
    alignItems: "center",
    gap: 8,
    borderTop: "1px solid #E5E7EB",
    paddingTop: 8,
  },
  input: {
    flex: 1,
    minHeight: 45,
    padding: 10,
    borderRadius: 8,
    border: "1px solid #E5E7EB",
    fontSize: 14,
    resize: "none",
  },
  sendBtn: {
    backgroundColor: "#5B21B6",
    color: "#fff",
    padding: "8px 18px",
    borderRadius: 8,
    border: "none",
    fontWeight: 600,
    cursor: "pointer",
  },
};

const emailStyles = {
  form: { display: "flex", flexDirection: "column", gap: 14, maxWidth: 700 },
  input: {
    padding: 12,
    borderRadius: 8,
    border: "1px solid #E5E7EB",
    fontSize: 15,
  },
  textarea: {
    minHeight: 160,
    padding: 12,
    borderRadius: 8,
    border: "1px solid #E5E7EB",
    fontSize: 15,
  },
  sendBtn: {
    backgroundColor: "#5B21B6",
    color: "#fff",
    padding: "10px 20px",
    borderRadius: 8,
    border: "none",
    fontWeight: 600,
    cursor: "pointer",
    alignSelf: "flex-start",
  },
};
