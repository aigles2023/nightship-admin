import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { db } from "../../../firebase/config";
import { doc, onSnapshot, getDoc } from "firebase/firestore";


export default function OrderDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [order, setOrder] = useState(null);
  const [driver, setDriver] = useState(null);

  useEffect(() => {
    if (!id) return;
    // Listen for updates to the order document
    const unsub = onSnapshot(doc(db, "orders", id), async (snap) => {
      if (!snap.exists()) {
        setOrder(null);
        return;
      }
      const data = snap.data();
      setOrder({ id: snap.id, ...data });
      // If driverId is present, load the driver info once
      const driverId = data.driverId || data.driverUID || data.driverUid;
      if (driverId) {
        try {
          const driverSnap = await getDoc(doc(db, "drivers", driverId));
          if (driverSnap.exists()) {
            setDriver({ id: driverSnap.id, ...driverSnap.data() });
          } else {
            setDriver(null);
          }
        } catch (err) {
          console.error("Error fetching driver info", err);
          setDriver(null);
        }
      } else {
        setDriver(null);
      }
    });
    return () => unsub();
  }, [id]);

  if (!order) {
    return (
      <div style={pageStyles.container}>
        <div style={pageStyles.header}>
          <button onClick={() => navigate(-1)} style={pageStyles.backBtn}>
            ← Back
          </button>
          <h2 style={pageStyles.title}>Order Details</h2>
        </div>
        <p>Loading order data...</p>
      </div>
    );
  }

  // Helper to format date values
  const formatDate = (ts) => {
    if (!ts) return "";
    const d = ts.toDate ? ts.toDate() : ts instanceof Date ? ts : null;
    return d ? d.toLocaleString() : "";
  };

  return (
    <div style={pageStyles.container}>
      <div style={pageStyles.header}>
        <button onClick={() => navigate(-1)} style={pageStyles.backBtn}>
          ← Back
        </button>
        <h2 style={pageStyles.title}>Order {order.orderNumber || order.id}</h2>
      </div>
      <div style={pageStyles.sectionRow}>
        <div style={pageStyles.section}>
          <h3 style={pageStyles.sectionTitle}>Sender</h3>
          <p><strong>Name:</strong> {order.senderName || ""}</p>
          <p><strong>Phone:</strong> {order.senderPhone || ""}</p>
          <p><strong>Email:</strong> {order.senderEmail || ""}</p>
        </div>
        <div style={pageStyles.section}>
          <h3 style={pageStyles.sectionTitle}>Recipient</h3>
          <p><strong>Name:</strong> {order.recipientName || order.receiverName || ""}</p>
          <p><strong>Phone:</strong> {order.recipientPhone || order.receiverPhone || ""}</p>
          <p><strong>Email:</strong> {order.receiverEmail || order.recipientEmail || ""}</p>
        </div>
      </div>
      <div style={pageStyles.sectionRow}>
        <div style={pageStyles.section}>
          <h3 style={pageStyles.sectionTitle}>Pickup</h3>
          <p>{order.pickupAddress || ""}</p>
          {order.pickupLat !== undefined && order.pickupLng !== undefined && (
            <p>Lat: {order.pickupLat?.toFixed?.(5) ?? order.pickupLat}, Lng: {order.pickupLng?.toFixed?.(5) ?? order.pickupLng}</p>
          )}
          <p>State: {order.pickupState || ""}</p>
        </div>
        <div style={pageStyles.section}>
          <h3 style={pageStyles.sectionTitle}>Dropoff</h3>
          <p>{order.dropoffAddress || ""}</p>
          {order.dropoffLat !== undefined && order.dropoffLng !== undefined && (
            <p>Lat: {order.dropoffLat?.toFixed?.(5) ?? order.dropoffLat}, Lng: {order.dropoffLng?.toFixed?.(5) ?? order.dropoffLng}</p>
          )}
          <p>State: {order.dropoffState || ""}</p>
        </div>
      </div>
      <div style={pageStyles.sectionRow}>
        <div style={pageStyles.section}>
          <h3 style={pageStyles.sectionTitle}>Payment</h3>
          <p><strong>Amount:</strong> ${order.payout?.toFixed?.(2) ?? order.payout}</p>
          <p><strong>Driver Gain:</strong> ${order.driverGain?.toFixed?.(2) ?? order.driverGain}</p>
          <p><strong>Platform Fee:</strong> ${order.platformFee?.toFixed?.(2) ?? order.platformFee}</p>
          <p><strong>Platform Share:</strong> ${order.platformShare?.toFixed?.(2) ?? order.platformShare}</p>
          <p><strong>Insurance:</strong> ${order.insuranceFee?.toFixed?.(2) ?? order.insuranceFee}</p>
          <p><strong>Taxes:</strong> ${order.taxFee?.toFixed?.(2) ?? order.taxFee}</p>
          <p><strong>Tip:</strong> ${order.tip?.toFixed?.(2) ?? order.tip}</p>
          {order.paymentMethodLast4 && (
            <p><strong>Payment Method:</strong> **** **** **** {order.paymentMethodLast4}</p>
          )}
        </div>
        <div style={pageStyles.section}>
          <h3 style={pageStyles.sectionTitle}>Order Info</h3>
          <p><strong>Status:</strong> {order.status}</p>
          <p><strong>Type:</strong> {order.type || order.orderType}</p>
          <p><strong>Date Created:</strong> {formatDate(order.createdAt || order.date)}</p>
          {order.deliveryDate && <p><strong>Delivered:</strong> {formatDate(order.deliveryDate)}</p>}
          {order.distanceMiles !== undefined && (
            <p><strong>Distance:</strong> {order.distanceMiles} miles</p>
          )}
          {order.durationMinutes !== undefined && (
            <p><strong>Duration:</strong> {order.durationMinutes} min</p>
          )}
        </div>
      </div>
      {driver && (
        <div style={pageStyles.sectionRow}>
          <div style={pageStyles.section}>
            <h3 style={pageStyles.sectionTitle}>Driver</h3>
            <p><strong>Name:</strong> {driver.name || driver.fullName || ""}</p>
            <p><strong>Phone:</strong> {driver.phone || driver.phoneNumber || ""}</p>
            <p><strong>Email:</strong> {driver.email || ""}</p>
          </div>
        </div>
      )}
    </div>
  );
}

// Basic inline styles for the details page
const pageStyles = {
  container: {
    padding: 24,
    maxWidth: 900,
    margin: "0 auto",
    fontFamily: "Inter, sans-serif",
    color: "#374151",
  },
  header: {
    display: "flex",
    alignItems: "center",
    marginBottom: 16,
  },
  backBtn: {
    marginRight: 16,
    padding: "4px 8px",
    fontSize: 14,
    backgroundColor: "#E5E7EB",
    border: "1px solid #D1D5DB",
    borderRadius: 4,
    cursor: "pointer",
  },
  title: {
    fontSize: 24,
    fontWeight: 700,
    margin: 0,
  },
  sectionRow: {
    display: "flex",
    flexWrap: "wrap",
    gap: 24,
    marginBottom: 24,
  },
  section: {
    flex: "1 1 300px",
    backgroundColor: "#FFFFFF",
    border: "1px solid #E5E7EB",
    borderRadius: 8,
    padding: 16,
    boxShadow: "0 1px 2px rgba(0,0,0,0.05)",
  },
  sectionTitle: {
    marginTop: 0,
    marginBottom: 8,
    fontSize: 16,
    fontWeight: 600,
  },
};