import React, { useEffect, useState } from "react";
import Sidebar from "../components/sidebar";
import { collection, onSnapshot } from "firebase/firestore";
import { db } from "../firebase/config";

export default function Orders() {
  const [orders, setOrders] = useState([]);
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [selectedOrder, setSelectedOrder] = useState(null); // ✅ pour la modale

  useEffect(() => {
    const unsubscribe = onSnapshot(
      collection(db, "orders"),
      (snapshot) => {
        const data = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setOrders(data);
      },
      (error) => {
        console.error("Erreur lors de la récupération des commandes :", error);
      }
    );
    return () => unsubscribe();
  }, []);

  const filteredOrders = orders.filter((order) => {
    const matchesFilter = filter === "all" ? true : order.status === filter;
    const matchesSearch = order.id
      .toLowerCase()
      .includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const getStatusColor = (status) => {
    switch (status) {
      case "pending":
        return "#F59E0B"; // orange
      case "accepted":
      case "in-progress":
        return "#2563EB"; // bleu
      case "completed":
        return "#16A34A"; // vert
      case "canceled_by_driver":
      case "canceled_by_client":
        return "#DC2626"; // rouge
      default:
        return "#6B7280"; // gris
    }
  };

  const closeModal = () => setSelectedOrder(null);

  return (
    <div style={layout.container}>
      <Sidebar />
      <main style={layout.main}>
        {/* --- HEADER --- */}
        <header style={styles.header}>
          <h1 style={styles.pageTitle}>All Orders</h1>

          <div style={styles.filterWrapper}>
            <label style={{ marginRight: 8 }}>📦 Filter by status:</label>
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              style={styles.select}
            >
              <option value="all">All</option>
              <option value="pending">Pending</option>
              <option value="accepted">Accepted</option>
              <option value="in-progress">In Progress</option>
              <option value="completed">Completed</option>
              <option value="canceled_by_driver">Canceled by Driver</option>
              <option value="canceled_by_client">Canceled by Client</option>
            </select>

            {/* 🔎 Recherche par numéro de commande */}
            <input
              type="text"
              placeholder="Search by Order ID..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              style={styles.searchInput}
            />
          </div>
        </header>

        {/* --- TABLE --- */}
        <div style={styles.tableCard}>
          <h4 style={styles.cardTitle}>Orders List</h4>
          <table style={styles.table}>
            <thead>
              <tr>
                <th style={styles.th}>ID</th>
                <th style={styles.th}>Status</th>
                <th style={styles.th}>Customer</th>
                <th style={styles.th}>Driver</th>
                <th style={styles.th}>Delivery Date</th>
                <th style={styles.th}>Details</th>
              </tr>
            </thead>
            <tbody>
              {filteredOrders.map((order, index) => (
                <tr
                  key={order.id}
                  style={{
                    backgroundColor:
                      index % 2 === 0 ? "#FFFFFF" : "#F9FAFB",
                    transition: "background-color 0.3s ease",
                  }}
                  onMouseEnter={(e) =>
                    (e.currentTarget.style.backgroundColor = "#EEF2FF")
                  }
                  onMouseLeave={(e) =>
                    (e.currentTarget.style.backgroundColor =
                      index % 2 === 0 ? "#FFFFFF" : "#F9FAFB")
                  }
                >
                  <td style={styles.td}>{order.id}</td>
                  <td
                    style={{
                      ...styles.td,
                      fontWeight: 600,
                      color: getStatusColor(order.status),
                    }}
                  >
                    {order.status}
                  </td>
                  <td style={styles.td}>{order.senderName || "—"}</td>
                  <td style={styles.td}>{order.acceptedBy || "Unassigned"}</td>
                  <td style={styles.td}>
                    {order.deliveryDate?.toDate?.().toLocaleString() || "—"}
                  </td>
                  <td style={styles.td}>
                    <button
                      style={styles.detailsBtn}
                      onClick={() => setSelectedOrder(order)}
                    >
                      View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {filteredOrders.length === 0 && (
            <p style={styles.noData}>No orders found for this filter.</p>
          )}
        </div>

        {/* --- MODALE DETAILS --- */}
        {selectedOrder && (
          <div style={modal.overlay}>
            <div style={modal.card}>
              <h3 style={modal.title}>Order Details</h3>
              <div style={modal.body}>
                <p><strong>Order ID:</strong> {selectedOrder.id}</p>
                <p><strong>Status:</strong> {selectedOrder.status}</p>
                <p><strong>Sender:</strong> {selectedOrder.senderName || "—"}</p>
                <p><strong>Address:</strong> {selectedOrder.pickupAddress || "—"}</p>
                <p><strong>Destination:</strong> {selectedOrder.dropoffAddress || "—"}</p>
                <p><strong>Amount Paid:</strong> ${selectedOrder.price || "0.00"}</p>
                <p><strong>Driver:</strong> {selectedOrder.acceptedBy || "Unassigned"}</p>
                <p><strong>Driver Phone:</strong> {selectedOrder.driverPhone || "—"}</p>
                <p><strong>Created at:</strong> {selectedOrder.createdAt?.toDate?.().toLocaleString() || "—"}</p>
                <p><strong>Accepted at:</strong> {selectedOrder.acceptedAt?.toDate?.().toLocaleString() || "—"}</p>
                <p><strong>Completed at:</strong> {selectedOrder.completedAt?.toDate?.().toLocaleString() || "—"}</p>
                <p><strong>Canceled at:</strong> {selectedOrder.canceledAt?.toDate?.().toLocaleString() || "—"}</p>
              </div>

              <button style={modal.closeBtn} onClick={closeModal}>
                Close
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

/* --- Layout (identique à Users) --- */
const layout = {
  container: {
    display: "flex",
    backgroundColor: "#F9FAFB",
    fontFamily: "Inter, sans-serif",
    color: "#374151",
    minHeight: "100vh",
  },
  main: {
    flexGrow: 1,
    padding: 32,
    overflowY: "auto",
    marginLeft: "var(--sidebar-width)",
    transition: "margin-left 0.3s ease",
  },
};

/* --- Styles page Orders --- */
const styles = {
  header: {
    display: "flex",
    justifyContent: "flex-start",
    alignItems: "center",
    paddingTop: '30px',
    gap: 16,
    flexWrap: "wrap",
    marginBottom: 24,
  },
  pageTitle: {
    fontSize: 26,
    fontWeight: 700,
    color: "#111827",
  },
  filterWrapper: {
    display: "flex",
    alignItems: "center",
    gap: 12,
    flexWrap: "wrap",
  },
  select: {
    padding: "6px 12px",
    border: "1px solid #E5E7EB",
    borderRadius: 6,
    backgroundColor: "#FFFFFF",
    fontSize: 14,
    transition: "all 0.3s ease",
    outline: "none",
    cursor: "pointer",
  },
  searchInput: {
    padding: "6px 12px",
    border: "1px solid #E5E7EB",
    borderRadius: 6,
    backgroundColor: "#FFFFFF",
    fontSize: 14,
    width: 220,
    transition: "all 0.3s ease",
  },
  tableCard: {
    backgroundColor: "#FFFFFF",
    border: "1px solid #E5E7EB",
    borderRadius: 12,
    padding: 20,
    boxShadow: "0 1px 3px rgba(0,0,0,0.03)",
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: 600,
    marginBottom: 16,
    color: "#111827",
  },
  table: {
    width: "100%",
    borderCollapse: "collapse",
  },
  th: {
    border: "1px solid #E5E7EB",
    padding: "12px",
    textAlign: "left",
    backgroundColor: "#5B21B6",
    fontSize: "14px",
    fontWeight: 600,
    color: "#FFFFFF",
  },
  td: {
    border: "1px solid #E5E7EB",
    padding: "12px",
    fontSize: "14px",
    color: "#374151",
  },
  detailsBtn: {
    padding: "6px 10px",
    backgroundColor: "#5B21B6",
    border: "none",
    color: "#fff",
    borderRadius: 6,
    cursor: "pointer",
    fontSize: "13px",
    fontWeight: 600,
    transition: "background 0.3s ease",
  },
  noData: {
    textAlign: "center",
    marginTop: 16,
    color: "#6B7280",
    fontSize: 14,
  },
};

/* --- Styles modale --- */
const modal = {
  overlay: {
    position: "fixed",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    background: "rgba(0,0,0,0.4)",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    zIndex: 1000,
  },
  card: {
    backgroundColor: "#fff",
    borderRadius: 12,
    padding: "24px 32px",
    width: "420px",
    maxHeight: "80vh",
    overflowY: "auto",
    boxShadow: "0 4px 20px rgba(0,0,0,0.2)",
    animation: "fadeIn 0.3s ease",
  },
  title: {
    fontSize: "20px",
    fontWeight: 700,
    marginBottom: 16,
    color: "#111827",
  },
  body: {
    display: "flex",
    flexDirection: "column",
    gap: 8,
    fontSize: "14px",
    color: "#374151",
  },
  closeBtn: {
    marginTop: 20,
    padding: "8px 16px",
    backgroundColor: "#5B21B6",
    color: "#fff",
    border: "none",
    borderRadius: 6,
    cursor: "pointer",
    alignSelf: "center",
  },
};
