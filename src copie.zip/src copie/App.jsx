import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { getAuth, onAuthStateChanged } from "firebase/auth";

// Layout
import AppLayout from "./layouts/applayout";

// Pages publiques
import Login from "./pages/login";
import ForgotPassword from "./pages/ForgotPassword";
import RegisterUser from "./pages/auth/RegisterUser";
import VerifyOpsAccess from "./pages/VerifyOpsAccess";

// Dashboards spécifiques
import OpsDashboard from "./pages/dashboards/OpsDashboard";
import SupervisorDashboard from "./pages/dashboards/SupervisorDashboard";
import ManagerDashboard from "./pages/dashboards/ManagerDashboard";
import CSDashboard from "./pages/dashboards/CSDashboard";

// ✅ Nouveaux dashboards simples
import OrdersDash from "./pages/orders-dash";
import UsersDash from "./pages/users-dash";
import LiveMapDash from "./pages/live-map-dash";
import SupportDash from "./pages/support-dash";
import SettingsDash from "./pages/settings-dash";
import AdminDash from "./pages/admin-dash";
import AuditLogsDash from "./pages/audit-logs-dash";
import TestPage from "./pages/test";


// Autres pages conservées
import AdminProfile from "./pages/admin_profile";
import ArchiveOrderDash from "./pages/archive-order-dash";
import EditAdminProfile from "./pages/edit_profile";
import ChangePassword from "./pages/change_password";
import CreateOrder from "./pages/create_order";
import Languages from "./pages/languages";
import About from "./pages/about";

import "./theme-fix.css";
import "./app.css";

const App = () => {
  const [user, setUser] = useState(undefined);
  const auth = getAuth();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      setUser(firebaseUser);
    });
    return () => unsubscribe();
  }, []);

  if (user === undefined) return null;

  return (
    <Router>
      <Routes>
        {/* --- Routes publiques --- */}
        <Route path="/login" element={<Login />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/register-user" element={<RegisterUser />} />
        <Route path="/verify-ops-access" element={<VerifyOpsAccess />} />

        {/* --- Dashboards principaux (accès direct) --- */}
        {user ? (
          <>
            <Route path="/cs-dashboard" element={<CSDashboard />} />
            <Route path="/ops-dashboard" element={<OpsDashboard />} />
            <Route path="/supervisor-dashboard" element={<SupervisorDashboard />} />
            <Route path="/manager-dashboard" element={<ManagerDashboard />} />

            {/* --- Nouveaux modules (avec Sidebar intégrée) --- */}
            <Route path="/orders" element={<OrdersDash />} />
   
            <Route path="/users" element={<UsersDash />} />
            <Route path="/live-map" element={<LiveMapDash />} />
            <Route path="/support" element={<SupportDash />} />
            <Route path="/settings" element={<SettingsDash />} />
            <Route path="/test" element={<TestPage />} />
            <Route path="/archive-order-dash" element={<ArchiveOrderDash />} />
            <Route path="/admin" element={<AdminDash />} />
            <Route path="/audit-logs" element={<AuditLogsDash />} />

            {/* --- Autres pages internes (ancien layout) --- */}
            <Route path="/admin-profile" element={<AdminProfile />} />
            <Route path="/edit-profile" element={<EditAdminProfile />} />
            <Route path="/change-password" element={<ChangePassword />} />
            <Route path="/create-order" element={<CreateOrder />} />
            <Route path="/languages" element={<Languages />} />
            <Route path="/about" element={<About />} />

            {/* Par défaut, redirection vers le CS Dashboard */}
            <Route path="*" element={<Navigate to="/cs-dashboard" />} />
          </>
        ) : (
          // 🔹 Non connecté → redirection login
          <Route path="*" element={<Navigate to="/login" />} />
        )}
      </Routes>
    </Router>
  );
};

export default App;
