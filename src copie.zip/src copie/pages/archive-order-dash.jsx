import React from "react";
import Sidebar from "../components/sidebar";

export default function ArchiveOrderDash() {
  return (
    <div style={layout.container}>
      <Sidebar />

      <main style={layout.main}>
        <h1 style={styles.title}>📦 Archive Orders Dashboard</h1>
        <p style={styles.text}>
          This is a <strong>new test layout</strong> for archived orders.  
          The sidebar should stay visible on the left, and this content appears clearly on the right.
        </p>

        <div style={styles.card}>
          <h3 style={styles.cardTitle}>Test Archive Order</h3>
          <p>This box confirms that your layout renders properly.</p>
        </div>
      </main>
    </div>
  );
}

/* ---- Layout général ---- */
const layout = {
  container: {
    display: "flex",
    backgroundColor: "#F9FAFB",
    fontFamily: "Inter, sans-serif",
    color: "#111827",
    minHeight: "100vh",
    width: "100%",
  },
  main: {
    flexGrow: 1,
    padding: "40px",
    marginLeft: "var(--sidebar-width)", // ✅ respecte la largeur du menu
    transition: "margin-left 0.3s ease",
    backgroundColor: "#F9FAFB",
    zIndex: 1,
  },
};

/* ---- Styles internes ---- */
const styles = {
  title: {
    fontSize: "28px",
    fontWeight: "700",
    marginBottom: "20px",
  },
  text: {
    fontSize: "16px",
    color: "#374151",
    marginBottom: "20px",
  },
  card: {
    backgroundColor: "#FFFFFF",
    border: "1px solid #E5E7EB",
    borderRadius: "12px",
    padding: "20px",
    maxWidth: "500px",
    boxShadow: "0 2px 6px rgba(0,0,0,0.05)",
  },
  cardTitle: {
    fontSize: "18px",
    fontWeight: "600",
    marginBottom: "8px",
  },
};
