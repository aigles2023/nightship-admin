import React from "react";
import Sidebar from '../components/sidebar';

export default function AuditLogsDash() {
  return (
    <div style={styles.container}>
      <Sidebar />
      <main style={styles.main}>
        <h1 style={styles.title}>🧾 Audit Logs</h1>
        <p style={styles.subtitle}>Review platform activity and historical records.</p>
      </main>
    </div>
  );
}

const styles = {
  container: {
    display: 'block',
    height: '100vh',
    backgroundColor: '#F9FAFB',
    fontFamily: 'Inter, sans-serif',
    color: '#374151',
    paddingLeft: 240,
  },
  main: {
    padding: 32,
    overflowY: 'auto',
  },
  title: {
    fontSize: '28px',
    fontWeight: 700,
    marginBottom: 16,
    color: '#111827',
  },
  subtitle: {
    fontSize: '16px',
    color: '#374151',
  },
};
