import React from "react";
import { Outlet } from "react-router-dom";
import Sidebar from "../components/sidebar";

const AppLayout = () => {
  return (
    <div style={styles.container}>
      {/* ✅ Barre latérale gauche fixe */}
      <Sidebar />

      {/* ✅ Contenu principal à droite */}
      <div style={styles.contentWrapper}>
        <main style={styles.main}>
          {/* ⚡ Toutes les pages (Users, Support, Test, etc.) s’affichent ici */}
          <Outlet />
        </main>
      </div>
    </div>
  );
};

const styles = {
  container: {
    display: "flex",
    minHeight: "100vh",
    backgroundColor: "#F9FAFB",
  },
  contentWrapper: {
    flexGrow: 1,
    marginLeft: "var(--sidebar-width)", // espace dynamique selon le collapse
    transition: "margin-left 0.3s ease",
    width: "100%",
  },
  main: {
    flexGrow: 1,
    padding: "32px",
    overflowY: "auto",
  },
};

export default AppLayout;
